<?php

namespace App\Providers;

use App\View\Components\AppLayout;
use App\View\Components\AppTrainer;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Blade::component('main-layout', AppTrainer::class);
        Blade::component('AppLayout', AppLayout::class);
    }
}
